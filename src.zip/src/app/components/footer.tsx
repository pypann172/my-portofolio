import Image from "next/image";
import Link from "next/link";
import { getProfil } from "@/lib/queries";

const footerLinks = [
    { label: "Home", href: "/" },
    { label: "Projects", href: "/proyek" },
    { label: "Skills", href: "/keahlian" },
    { label: "About", href: "/tentang" },
    { label: "Contact", href: "/kontak" },
];

export default async function Footer() {
    const profile = await getProfil();
    const fullName = profile?.namaLengkap ?? "";
    const displayName = profile?.namaTampil ?? "";
    const email = profile?.email ?? "";
    const githubUrl = profile?.githubUrl ?? "";
    const location = profile?.kota ?? "";

    return (
        <footer className="global-footer mt-auto border-t border-blue-200 bg-blue-950 text-blue-50">
            <div className="mx-auto grid w-full max-w-6xl gap-10 px-5 py-12 sm:px-8 sm:py-14 lg:grid-cols-[1.2fr_0.8fr_0.8fr] lg:gap-12">
                <div>
                    <Link href="/" className="inline-flex items-center gap-3" aria-label="Kembali ke halaman utama Ipann">
                        <Image src={profile?.logo || "/ipann/logoIpann.jpg"} alt={`Logo ${displayName}`} width={42} height={42} className="h-10 w-10 rounded-xl object-contain" />
                        <span className="text-lg font-bold tracking-tight">{displayName}</span>
                    </Link>
                    <p className="mt-5 max-w-sm text-sm leading-7 text-blue-200/75">
                        Portfolio pribadi {fullName}, siswa {profile?.jurusan ?? ""} pada {profile?.sekolah ?? ""}.
                    </p>
                </div>

                <div>
                    <p className="text-xs font-bold uppercase tracking-[0.2em] text-sky-300">Explore</p>
                    <nav className="mt-4 grid grid-cols-2 gap-x-5 gap-y-3 text-sm" aria-label="Footer navigation">
                        {footerLinks.map((link) => (
                            <Link key={link.href} href={link.href} className="text-blue-100/75 transition-colors hover:text-white">{link.label}</Link>
                        ))}
                    </nav>
                </div>

                <div>
                    <p className="text-xs font-bold uppercase tracking-[0.2em] text-sky-300">Get in touch</p>
                    <div className="mt-4 space-y-3 text-sm">
                        <a href={`mailto:${email}`} className="block break-all text-blue-100/75 transition-colors hover:text-white">{email}</a>
                        <a href={githubUrl} target="_blank" rel="noreferrer" className="block text-blue-100/75 transition-colors hover:text-white">GitHub ↗</a>
                        <p className="text-blue-200/55">{location}, Indonesia</p>
                    </div>
                </div>
            </div>
            <div className="border-t border-blue-800/80">
                <div className="mx-auto flex w-full max-w-6xl flex-col gap-2 px-5 py-5 text-xs text-blue-200/60 sm:flex-row sm:items-center sm:justify-between sm:px-8">
                    <p>© {new Date().getFullYear()} {displayName}.</p>
                    <p>Portfolio pribadi</p>
                </div>
            </div>
        </footer>
    );
}
